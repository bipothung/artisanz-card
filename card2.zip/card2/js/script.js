// JavaScript function to update the displayed image and flavor
function updateImage(imgElement, imageUrl, drinkName) {
  // Get selected image URL or use default if not provided
  var selectedImage = imageUrl || imgElement.src;
  // Update the displayed image
  document.getElementById("cardImage").src = selectedImage;
  // Update the displayed drink name
  document.getElementById("cardTitle").innerText = drinkName;

  // Remove 'selected' class from all images
  var images = document.querySelectorAll(".child-img img");
  images.forEach(function (img) {
    img.classList.remove("selected");
  });

  // Add 'selected' class to the clicked image
  imgElement.classList.add("selected");
}
